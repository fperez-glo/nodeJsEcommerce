import { app } from "../../main.js";
import request from "supertest";
import { expect, assert } from "chai";
import { AuthService } from "../api/services/auth.service.js";

const authService = new AuthService();

describe('API Authenticacion - /', ()=> {

    it('', ()=> {

    })


})